package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PalmerBrenda674Week8Application {

	public static void main(String[] args) {
		SpringApplication.run(PalmerBrenda674Week8Application.class, args);
	}

}
