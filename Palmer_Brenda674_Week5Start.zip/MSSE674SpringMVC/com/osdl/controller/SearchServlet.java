/**
 * 
 */
package com.osdl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.osdl.bean.SearchBean;
import com.osdl.business.SearchManager;

/**
 * @author Brenda Palmer
 *
 */
public class SearchServlet extends HttpServlet {

	private static final long serialVersionUID = 102531973239L;

	SearchBean sb = new SearchBean();

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		 sb.setLanguage(req.getParameter("language"));
		 String language = sb.getLanguage();
		//String skill = sb.setSkill(req.getParameter("skill"));

		SearchManager sm = new SearchManager();
		String lang = sm.search(language);

		if (lang != null) {
			RequestDispatcher rd = req.getRequestDispatcher("SearchResults.html");
			rd.include(req, res);
			System.out.println("Here is a list of your search results, please select a book to reserve");

		} else {
			RequestDispatcher rd = req.getRequestDispatcher("SearchError.html");
			rd.forward(req, res);
			System.out.println("Please enter a valid language and skill level");

		}

	}

}
