/**
 * 
 */
package com.osdl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

/**
 * @author Brenda Palmer
 *
 */
@Controller
public class LoginController {
	
	//@RequestMapping("/login", method = RequestMethod.POST)
	//public ModelAndView login(HttpServletRequest req, HttpServletResponse res) {
		
		loginBean.setUserName(req.getParameter("username"));
		String username = loginBean.getUserName();
		
		//ModelAndView mv = new ModelAndView();
		//mv.setViewName("Login.jsp");
		//mv.addObject(userName, username);
		
	//	return mv;
		 @RequestMapping(value = "/login", method = RequestMethod.POST)
		  public String handleLoginRequest(@RequestParam String username, ModelMap modelMap){
modelMap.put("username", username);

return "Search.jsp";

	}

}
