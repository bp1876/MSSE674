/**
 * 
 */
package com.osdl.filters;

import java.io.IOException;
import java.util.zip.GZIPOutputStream;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Brenda Palmer
 *
 */
//This is the GZIP filter
public class CompressionFilter implements Filter {

	private ServletContext ctx;
	private FilterConfig cfg;

	public void init(FilterConfig cfg) throws ServletException {

		this.cfg = cfg;
		ctx = cfg.getServletContext();
		ctx.log(cfg.getFilterName() + "Filter intialized");

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain fc) throws IOException, ServletException {

		System.out.println("Inside the GZIP filter's doFilter method");

		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		String valid_gZipEncoding = request.getHeader("Accept GZIP");
		if (valid_gZipEncoding.indexOf("gzip") > -1) {

			CompressionWrapper reswrapper = new CompressionWrapper(response);
			reswrapper.setHeader("Content", "gzip");

			fc.doFilter(request, reswrapper);

			GZIPOutputStream gzos = reswrapper.getGZIPServletOutputStream();
			gzos.finish();

			ctx.log(cfg.getFilterName() + "completed the filter request");
		} else {

			ctx.log(cfg.getFilterName() + "not a GZIP");
			fc.doFilter(request, response);
		}

	}

	public void destroy() {

		// resetting instance variables
		cfg = null;
		ctx = null;
	}

}
