/**
 * 
 */
package com.osdl.filters;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.zip.GZIPOutputStream;
import javax.servlet.*;

/**
 * @author Brenda Palmer
 *
 */
public class CompressionWrapper extends HttpServletResponseWrapper {

	public CompressionWrapper(HttpServletResponse response) {
		super(response);
		// TODO Auto-generated constructor stub
	}

	private GZIPServletOutputStream Gzip = null;
	private PrintWriter pw = null;

	public void setContentLength(int len) {
	}

	public GZIPOutputStream getGZIPServletOutputStream() {

		return this.Gzip.internalGzipOS;
	}

	private Object streamUsed = null;

	public ServletOutputStream getOutputStream() throws IOException {

		if ((streamUsed != null && streamUsed == pw)) {
			throw new IllegalStateException();

		}

		if (Gzip == null) {

			Gzip = new GZIPServletOutputStream(getResponse().getOutputStream());

			streamUsed = Gzip;
		}

		return Gzip;
	}

	public PrintWriter getWriter() throws IOException {

		if ((streamUsed != null) && (streamUsed == Gzip)) {

			throw new IllegalStateException();
		}

		if (pw == null) {
			Gzip = new GZIPServletOutputStream(getResponse().getOutputStream());

			OutputStreamWriter write = new OutputStreamWriter(Gzip, getResponse().getCharacterEncoding());

			pw = new PrintWriter(write);
			streamUsed = pw;
		}

		return pw;

	}

}
