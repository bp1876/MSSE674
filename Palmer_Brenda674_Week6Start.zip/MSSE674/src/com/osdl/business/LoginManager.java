/**
 * 
 */
package com.osdl.business;

import com.osdl.bean.LoginBean;
import com.osdl.bean.OSDLComposite;
import com.osdl.service.Factory;
import com.osdl.service.ILoginService;

/**
 * @author Brenda Palmer
 *
 */
public class LoginManager {

	public LoginManager() {
		super();

	}

	public static LoginBean authenticateLogin(LoginBean login) {
		LoginBean log = new LoginBean();
		
		if ((login.getUserName().equals("brenda")))  {
			log.setUserName(login.getUserName());
		
		} else {
			log = null;
		}
		
		return log;
	}
}
