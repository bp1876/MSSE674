/**
 * 
 */
package com.osdl.business.tests;

import org.junit.Before;
import org.junit.Test;

import com.osdl.bean.LoginBean;
import com.osdl.business.LoginManager;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class LoginManagerTest extends TestCase {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

		@Test
		public void testLogin() {
			LoginBean login = new LoginBean();
			login.setUserName("brenda");
			
			LoginBean log = LoginManager.authenticateLogin(login);
			assertNotNull("Failed to authenticate user", log);
		}

}
