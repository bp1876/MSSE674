/**
 * 
 */
package com.osdl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

/**
 * @author Brenda Palmer
 *
 */
@Controller
public class LoginController {

	   @RequestMapping("/Login", method = RequestMethod.POST)  
	   public String login(HttpServletRequest req, HttpServletResponse res) {
		
		  LoginBean loginBean = new LoginBean();
		 String user = loginBean.setUserName(req.getParameter("user"));
		
		 
		 LoginBean login = OSDLComposite.update(user);
		 
	      String message;
	      if(login != null {
	    	 // message = "Welcome " + userName;
	    	  response.sendRedirect("/Search");
		      //return "Search";  
	 
	      }else{
	    	  message = "Wrong username";
	    	  response.sendRedirect("/LoginError");
	    	 // return new ModelAndView("LoginError",  "message", message);
	    	 // return "LoginError";
	      }
	   }

	// LoginBean login = OSDLComposite.update(this);

}
