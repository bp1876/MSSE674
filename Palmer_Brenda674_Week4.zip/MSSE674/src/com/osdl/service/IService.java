/**
 * 
 */
package com.osdl.service;

/**
 * @author Brenda Palmer
 * 
 * Marker Interface
 *
 */
public interface IService {

}
