/**
 * 
 */
package com.osdl.dao;

import com.osdl.bean.LoginBean;

/**
 * @author Brenda Palmer
 *
 */
public class LoginDao {

	//public String authenticateUser(LoginBean loginBean) {

	//	String user = "brenda";
	//	String pass = "test";

	//	String userName = loginBean.getUserName();
	//	String password = loginBean.getPassword();

	//	if (userName.equals("brenda") && password.equals("test")) {

	//		return "Success";

	//	}
	//	else {

	//	return "Invalid credentials, try again";
	//	}
	//}
	
	
	
	
	
	//The below will go into the servlet once I get to the db week 
	
	//LoginDao loginDao = new LoginDao();
	
	
			//String userValidate = loginDao.authenticateUser(loginBean);

			// RequestDispatcher rd = null;
			
			//if (userValidate.equals("Success")) {
				//req.setAttribute("username", username);
				//req.setAttribute(password, password);
				
			//	rd = req.getRequestDispatcher("Search.html");
	         //   rd.include(req, res);
				
				//res.sendRedirect("Search.html");
			//} else {
		//	req.setAttribute("error", userValidate);
		//	res.sendRedirect("Login.html");
		//	}
			
			//if(userName.equals("brenda") && password.equals("test")) {
				
				//res.sendRedirect("Search.html");
			//	
			//	res.encodeRedirectUrl("http://localhost:8080/MSSE674/Service.html");
			//}else {
				
			//	res.sendRedirect("Login.html");
			//}
		}

		// String username1 = loginBean.setUserName(req.getParameter("username"));
		// String pass1 = loginBean.setPassword(req.getParameter("password"));

