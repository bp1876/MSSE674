/**
 * 
 */
package com.osdl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author Brenda Palmer
 *
 */
@Controller
public class LoginController {

	   @RequestMapping(path ="/login", method = RequestMethod.POST)  
	   public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		
		  String userName=request.getParameter("userName");  
	     
	      String message;
	      if(userName != null && !userName.equals("")  && userName.equals("brenda")) {
	    	  message = "Welcome " + userName;
	    	 // response.sendRedirect("/Search.jsp");
		      return new ModelAndView("Search", "message", message);  
	 
	      }else{
	    	  message = "Wrong username";
	    	//  response.sendRedirect("/LoginError.jsp");
	    	  return new ModelAndView("LoginError",  "message", message);
	      }
	   }

	// LoginBean login = OSDLComposite.update(this);

}
