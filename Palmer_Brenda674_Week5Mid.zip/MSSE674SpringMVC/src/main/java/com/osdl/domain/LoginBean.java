/**
 * 
 */
package com.osdl.domain;

import java.io.Serializable;


/**
 * @author Brenda Palmer
 *
 */


public class LoginBean implements Serializable {

	private static final long serialVersionUID = 1094801825228386363L;
	
	
	private String userName;
	private String password;


	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	public LoginBean() {
		
	}
	
	public LoginBean(LoginBean login) {
		
		this.userName = login.userName;
		this.password = login.password;
		
	}
	
	public LoginBean(String userName, String password) {
		
		this.userName = userName;
		this.password = password;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoginBean other = (LoginBean) obj;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "LoginBean [userName=" + userName + ", password=" + password + "]";
	}

	//public String loginAuthentication() throws Exception {

	//	LoginBean login = OSDLComposite.update(this);
	//	if (login == null) {
			//ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
			//ec.redirect(ec.getRequestContextPath() + "/failedLogin.xhtml");
			//return "failedLogin";
		//} else {
			//ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
			//ec.redirect(ec.getRequestContextPath() + "/Search.xhtml");
			//return "Search";
	//	}
//
	//}

	//For JUnit test
	public boolean validate() {

		if (userName == "")
			return false;
		if (password == "")
			return false;

		return true;
		
		
	}

}
