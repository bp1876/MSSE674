/**
 * 
 */
package com.osdl.service;

import java.sql.Connection;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.osdl.domain.LoginBean;



/**
 * @author Brenda Palmer
 *
 */
public class LoginJDBCImpl implements ILoginService {
	
	@Resource(name = "jdbc/msse674")
    DataSource ds;

	public LoginJDBCImpl() {

	}

	public boolean updateDbSrv(LoginBean login) {
		System.out.println("Entering method LoginJDBCImpl:" + "in the database.");
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			ds = (DataSource) envCtx.lookup("jdbc/msse674");
			
			Connection connect = ds.getConnection();
			Statement s = connect.createStatement();
			System.out.println("Successfully made connection to the database");
			
			String userName = login.getUserName();
			
			String sqlupdatequery = String.format(
					"UPDATE login SET userName = '%s';" , userName);
			int result = s.executeUpdate(sqlupdatequery);
			System.out.println("Udate to database successful and the result is "+ result);
			
			// Close the statement
			s.close();
			// Close the database connection
			connect.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

}
