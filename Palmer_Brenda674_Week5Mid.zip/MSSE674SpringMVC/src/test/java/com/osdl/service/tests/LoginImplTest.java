package com.osdl.service.tests;

import org.junit.Test;

import com.osdl.domain.LoginBean;
import com.osdl.service.Factory;
import com.osdl.service.LoginJDBCImpl;

import junit.framework.TestCase;

/**
 * 
 */

/**
 * @author Brenda Palmer
 *
 */
public class LoginImplTest extends TestCase {
	private Factory serviceFactory;

	protected void setUp() throws Exception {
		super.setUp();

		serviceFactory = Factory.getInstance();

	}

	@Test
	public void test() {
		try {
			LoginJDBCImpl JDBCImpl = new LoginJDBCImpl();
			LoginBean login = new LoginBean();
			login.setUserName("brenda");

			assertTrue(JDBCImpl.updateDbSrv(login));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
