/**
 * 
 */
package com.osdl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

/**
 * @author Brenda Palmer
 *
 */
@Controller
public class LoginController {

	   @RequestMapping("/Login", method = RequestMethod.POST)  
	   public ModelAndView login(HttpServletRequest req, HttpServletResponse res) {
		
		  LoginBean loginBean = new LoginBean();
		  loginBean.setUserName(req.getParameter("username"));
		  String username = loginBean.getUserName();
		   
		 // String userName=request.getParameter("userName");  
	     
	      String message;
	      if(userName != null {
	    	  message = "Welcome " + userName;
	    	 // response.sendRedirect("/Search");
		      return new ModelAndView("Search", "message", message);  
	 
	      }else{
	    	  message = "Wrong username";
	    	 // response.sendRedirect("/LoginError");
	    	  return new ModelAndView("LoginError",  "message", message);
	      }
	   }

	// LoginBean login = OSDLComposite.update(this);

}
