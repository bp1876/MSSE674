/**
 * 
 */
package com.osdl.service;

import javax.naming.Context;
import javax.naming.InitialContext;

/**
 * @author Brenda Palmer
 *
 */
public class Factory {

	public Factory() {
	}

	private static Factory FactoryInstance;

	private static String getImplName(String name) throws Exception {
		Context iniCtx = new InitialContext();
		Context envCtx = (Context) iniCtx.lookup("java:comp/env");
		return (String) envCtx.lookup(name);
	}

	public IService getService(String svcName) throws Exception {

		try {
			Class<?> c = Class.forName(getImplName(svcName));
			return (IService) c.newInstance();
		} catch (Exception e) {
			svcName = svcName + "service unable to load";
			throw new Exception(svcName, e);
		}

	}

	public static Factory getInstance() {
		if (FactoryInstance == null) {
			FactoryInstance = new Factory();
		}
		return FactoryInstance;
	}
}
