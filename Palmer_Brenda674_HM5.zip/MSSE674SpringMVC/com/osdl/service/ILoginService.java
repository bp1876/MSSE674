/**
 * 
 */
package com.osdl.service;

import com.osdl.domain.LoginBean;
import com.osdl.domain.OSDLComposite;

/**
 * @author Brenda Palmer
 *
 */
public interface ILoginService extends IService {

	public final String NAME = "ILoginService";

	public boolean updateDbSrv(LoginBean login);

}
