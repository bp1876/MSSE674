/**
 * 
 */
package com.osdl.domain;

import com.osdl.controller.LoginController;
import com.osdl.service.Factory;
import com.osdl.service.ILoginService;

/**
 * @author Brenda Palmer
 *
 */
public class OSDLComposite {

	public static String update(LoginBean loginBean) throws Exception {

		LoginBean lb = new LoginBean();
		if (loginBean.getUserName() !=null && loginBean.getUserName().equalsIgnoreCase("brenda")) {
			
		} else {
			System.out.println("Update method called.  Now trying to udpate the database :: "+loginBean.getUserName());
			
			Factory factory = Factory.getInstance();
			ILoginService logSrv = (ILoginService) factory.getService(ILoginService.NAME);

			logSrv.updateDbSrv(loginBean);
			
		}

		return loginBean.getUserName();
	}

	public static String update(LoginController loginController) {
		// TODO Auto-generated method stub
		return null;
	}

}
