/**
 * 
 */
package com.osdl.bean;

import com.osdl.service.Factory;
import com.osdl.service.ILoginService;

/**
 * @author Brenda Palmer
 *
 */
public class OSDLComposite {

	public static LoginBean update(LoginBean loginBean) throws Exception {

		LoginBean lb = new LoginBean();
		if (loginBean.getUserName() !=null && loginBean.getUserName().equalsIgnoreCase("brenda")) {
			
		} else {
			System.out.println("Update method called.  Now trying to udpate the database :: "+loginBean.getUserName());
			
			Factory factory = Factory.getInstance();
			ILoginService logSrv = (ILoginService) factory.getService(ILoginService.NAME);

			logSrv.updateDbSrv(loginBean);
			
		}

		return lb;
	}

}
