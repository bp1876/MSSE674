/**
 * 
 */
package com.osdl.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Brenda Palmer
 *
 */
//This is the GZIP filter
public class CompressionFilter implements Filter {

	public void init(FilterConfig cfg) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		System.out.println("Inside the GZIP filter's doFilter method");

		HttpServletRequest httpRequest = (HttpServletRequest) req;
		HttpServletResponse httpResponse = (HttpServletResponse) res;

		if (acceptsGZipEncoding(httpRequest)) {
			httpResponse.addHeader("Content-Encoding", "gzip");
			CompressionWrapper gzipResponse = new CompressionWrapper(httpResponse);
			chain.doFilter(req, gzipResponse);
			gzipResponse.close();
		} else {
			chain.doFilter(req, res);
		}
		
		System.out.println("Existing Gzip Compression Filter");
	}

	private boolean acceptsGZipEncoding(HttpServletRequest httpRequest) {
		String acceptEncoding = httpRequest.getHeader("Accept-Encoding");

		return acceptEncoding != null && acceptEncoding.indexOf("gzip") != -1;
	}

	public void destroy() {

		// This is empty but needed to destroy filter after use
	}

}
