import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.osdl.business.tests.LoginManagerTest;
import com.osdl.business.tests.SearchManagerTest;

@RunWith(Suite.class)
@SuiteClasses({LoginManagerTest.class, SearchManagerTest.class, LoginImplTest.class })
public class AllTests {

}
