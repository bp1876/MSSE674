/**
 * 
 */
package com.osdl.filters;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Brenda Palmer
 *
 */
//Tracking Filter
public class LoginRequestFilter implements Filter{
	
	private FilterConfig fc;
	
	public void init(FilterConfig config) throws ServletException{
		
		this.fc = config;
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
		System.out.println("Inside the tracking filter doFilter method");
		
		HttpServletRequest httpReq = (HttpServletRequest) req;
		HttpServletResponse httpRes = (HttpServletResponse) res;
		
		
		String reqURI = httpReq.getRequestURI();
		
		String loginURL = ((HttpServletRequest) req).getContextPath() + "/Login.xhtml";
		
		if(reqURI != null) {
			
			fc.getServletContext().log("Requested URI is: " + reqURI);
		} else {
			httpRes.sendRedirect(loginURL); 
		}
		chain.doFilter(req, res);
		
		System.out.println("Existing Tracking Filter");
	}
	
	public void destroy() {
		
		//empty method, used to destroy the filter after it has been used
	}

}
