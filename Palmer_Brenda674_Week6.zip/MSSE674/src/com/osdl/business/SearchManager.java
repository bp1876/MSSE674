/**
 * 
 */
package com.osdl.business;

/**
 * @author Brenda Palmer
 *
 */
public class SearchManager {

	public String search(String lang) {

		if (lang.isEmpty()) {

			return null;
		}

		return "success";
	}

}
